package com.capgemini.bank.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.BankAccount;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.dao.bankDao;
import com.capgemini.bank.dao.bankDaoImpl;
import com.capgemini.bank.exception.bankException;

public class bankserviceimpl implements bankservice {
	bankDao bankdao=new bankDaoImpl();
	@Override
	public int createAccount(BankAccount account) throws bankException {
		return bankdao.createAccount(account);
	}

	@Override
	public double showBalance(int accountno) throws bankException {
		return bankdao.showBalance(accountno);
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) throws bankException {
		return bankdao.deposit(accountno, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) throws bankException {
		return bankdao.withdraw(accountno, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount)
			throws bankException {
		return bankdao.fundTransfer(sourceAccountno, destinationAccountNo, amount);
	}

	@Override
	public List<Transaction> printTransactions(int accountno) throws bankException {
		return bankdao.getAllTransactions(accountno);
	}

	@Override
	public boolean isNameValid(String name) throws bankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new bankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean isMailValid(String mail) throws bankException {
		Pattern mailPattern = Pattern.compile("[A-Za-z][@gmail.com]");
		Matcher matcher = mailPattern.matcher(mail);
		if (matcher.matches())
			throw new bankException("Invalid mail ID");
		else
			return false;
	}

	@Override
	public boolean isMobileValid(String mobile) throws bankException {
		String input1 = String.valueOf(mobile);
		Pattern mobilePattern = Pattern.compile("[7,8,9]{1}[0-9]{9}");
		Matcher matcher = mobilePattern.matcher(input1);
		if (matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean isAddressValid(String address) throws bankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, address)) {
			throw new bankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

}
