package com.capgemini.bank.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.bank.bean.BankAccount;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.bankException;

public interface bankservice {
	public int createAccount(BankAccount account) throws bankException;
	public double showBalance(int accountno) throws bankException;
	List<Transaction> deposit(int accountno, double amount) throws bankException;
	List<Transaction> withdraw(int accountno, double amount) throws bankException;
	List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount) throws bankException;
	List<Transaction> printTransactions(int accountno) throws bankException;
	public boolean isNameValid(String name) throws bankException;
	public boolean isMailValid(String mail) throws bankException;
	public boolean isMobileValid(String mobile) throws bankException;
	public boolean isAddressValid(String address) throws bankException;
}

