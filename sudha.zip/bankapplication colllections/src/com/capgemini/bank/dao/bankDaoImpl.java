package com.capgemini.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.BankAccount;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.utility.BankRepositories;

public class bankDaoImpl implements bankDao {
	static Map<Integer, BankAccount> map = new HashMap<>();
	@Override
	public int createAccount(BankAccount account) {
		map.putAll(BankRepositories.getAccount());
		int accountNo = (int) (Math.random() * 1000);
	    account.setAccountNo(accountNo);
		map.put(accountNo, account);
		return accountNo;
	}

	@Override
	public double showBalance(int accountno) {
	
		map.putAll(BankRepositories.getAccount());
		double balance = 0;
		boolean status = map.containsKey(accountno);
		if (status == false) {
			try {
				throw new Exception("Account Number is not listed...");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			BankAccount customer = map.get(accountno);
			balance = customer.getBalance();
		}
		return balance;
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) {
		map.putAll(BankRepositories.getAccount());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList = new ArrayList<>();
		BankAccount customer = map.get(accountno);
		double balance = customer.getBalance() + amount;
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(accountno, transactionId, "Deposit", date, balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		transactionlist.add(transaction);
		return transactionList;

	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) {
		map.putAll(BankRepositories.getAccount());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList = new ArrayList<>();
	BankAccount account = map.get(accountno);
		double balance = account.getBalance() - amount;
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(accountno, transactionId, "Withdraw", date, balance);
		transactionList.add(transaction);
	      account.setBalance(balance);
		transactionlist.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountNo, int destinationAccountNo, double amount) {
		map.putAll(BankRepositories.getAccount());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList2 = new ArrayList<>();
		BankAccount account = map.get(sourceAccountNo);
		double balance = account.getBalance() - amount;
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(sourceAccountNo, transactionId, "Deposit", date, balance);
		transactionList2.add(transaction);
		BankAccount customer1 = map.get(destinationAccountNo);
		double balance1 = customer1.getBalance() + amount;
		customer1.setBalance(balance);
		transactionlist.add(transaction);
		return transactionList2;
	}

	@Override
	public List<Transaction> getAllTransactions(int accountno) {
		List<Transaction> transactionList3 = new ArrayList<>();
		int size = transactionlist.size();
		for (int i = 0; i < size; i++) {
			Transaction transaction = transactionlist.get(i);
			if (transaction.getAccountNo() == accountno)
				transactionList3.add(transaction);
		}
		return transactionList3;
	}
	}

