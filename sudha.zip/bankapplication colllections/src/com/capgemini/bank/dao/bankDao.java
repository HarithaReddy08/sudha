package com.capgemini.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.BankAccount;
import com.capgemini.bank.bean.Transaction;

public interface bankDao {
		static List<Transaction> transactionlist = new ArrayList<>();
		Map<Integer, BankAccount> bankaccountlist = new HashMap<>();
		public int createAccount(BankAccount account);
		public double showBalance(int accountno);
		List<Transaction> deposit(int accountno, double amount);
		List<Transaction> withdraw(int accountno, double amount);
		List<Transaction> fundTransfer(int sourceAccountNo,int destinationAccountNo,double amount);
		List<Transaction> getAllTransactions(int accountno);
}
