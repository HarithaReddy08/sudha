package com.capgemini.bank.exception;

public class bankException extends Exception {

	public bankException(String message) {
		super(message);
	}

	public bankException() {
		super();
		
	}

	public bankException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public bankException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}


	public bankException(Throwable arg0) {
		super(arg0);
	
	}
	

}
