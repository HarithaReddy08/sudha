package com.capgemini.bank.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bank.bean.BankAccount;

public class BankRepositories {
	
	private static Map<Integer,BankAccount> account = new HashMap<>();
	static {
		account.put(145, new BankAccount(145,"Sravani","sravanireddy6197@gmail.com","9154102973","Hyderabad",50000));
		account.put(256, new  BankAccount(256,"Sudha","sudhapadma6197@gmail.com","9154106197","Bangalore",100000));
		account.put(321, new BankAccount(321,"Ramya","ramyavagdevi@gmail.com","8919139935","Kakinada",55555));
		account.put(973, new  BankAccount(973,"Harini","harinireddy1345@gmail.com","9154109273","Mumbai",80000));
	}
	public static Map<Integer, BankAccount> getAccount() {
		return account;
	}
	public static void setAccount(Map<Integer, BankAccount> account) {
		BankRepositories.account = account;
	}

	
}
