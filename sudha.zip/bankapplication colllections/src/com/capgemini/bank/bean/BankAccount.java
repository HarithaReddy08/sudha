package com.capgemini.bank.bean;

public class BankAccount {
	private int accountNo;
	private String name;
	private String email;
	private String mobile;
	private String address;
	private double balance;
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankAccount(int accountNo, String name, String email, String mobile, String address, double balance) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.balance = balance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", name=" + name + ", email=" + email + ", mobile=" + mobile
				+ ", address=" + address + ", balance=" + balance + "]";
	}
	
}