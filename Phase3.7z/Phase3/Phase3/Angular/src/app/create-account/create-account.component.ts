import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {

  customer: Customer;
  constructor(private customerService: CustomerService) {

  }

  createCustomer(fName: string, lName: string, age: number, password: string, amount: number): void {
    if (fName && lName && age && password && amount) {
      this.customer = new Customer(fName, lName, age, password, amount);
      this.customerService.createCustomer(this.customer)
        .subscribe(data => {
          alert('Account Created Successfully!');
        });
    } else {
      alert('Please fill all details');
    }

  }
}
