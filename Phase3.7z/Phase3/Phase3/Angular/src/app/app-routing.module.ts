import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';

import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';

import { WelcomeComponent } from './welcome/welcome.component';





const routes: Routes = [
  { path: 'create', component: CreateAccountComponent },
  {path : 'balance', component : ShowBalanceComponent},
  {path : 'deposit', component : DepositComponent},
  {path : 'withdraw', component : WithdrawComponent},
  {path : 'transfer', component : FundTransferComponent},
  {path : 'print', component : PrintTransactionComponent},
  {path: '', component: WelcomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
