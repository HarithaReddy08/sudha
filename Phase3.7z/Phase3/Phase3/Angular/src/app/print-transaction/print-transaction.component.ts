import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

import { Transaction } from '../transaction';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {
  transaction: Transaction[];
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }

  getTransaction(accountNumber: number) {
    if (accountNumber) {
      this.customerService.getTransactionsByAccountNumber(accountNumber).subscribe(data => {
        if (data != null && data.length > 0) {
          this.transaction = data;
        } else {
          alert('No Transactions found');
        }
      });
    } else {
      alert('Enter Account number!');
    }
  }
}
